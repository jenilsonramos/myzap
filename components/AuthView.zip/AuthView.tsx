
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface AuthViewProps {
    onLogin: (credentials: any) => void;
    onSignup: (data: any) => void;
    onRecover: (email: string) => void;
    initialView?: 'login' | 'signup' | 'recover';
    onToggleTheme: () => void;
    isDarkMode: boolean;
}

const AuthView: React.FC<AuthViewProps> = ({
    onLogin,
    onSignup,
    onRecover,
    initialView = 'login',
    onToggleTheme,
    isDarkMode
}) => {
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(false);

    const [formData, setFormData] = useState({
        email: '',
        password: '',
        confirmPassword: '',
        name: ''
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);

        setTimeout(() => {
            setIsLoading(false);
            if (initialView === 'login') onLogin({ email: formData.email, password: formData.password });
            else if (initialView === 'signup') onSignup(formData);
            else onRecover(formData.email);
        }, 1500);
    };

    const renderLoginForm = () => (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-2">
                <label className="text-xs font-semibold uppercase tracking-widest text-slate-500 dark:text-slate-400 ml-1">Email</label>
                <div className="relative group">
                    <span className="material-icons-round absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors">alternate_email</span>
                    <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="seu@email.com"
                        className="w-full bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-primary/20 focus:bg-white dark:focus:bg-white/10 rounded-2xl py-4 pl-14 pr-6 text-sm text-slate-900 dark:text-white outline-none transition-all shadow-sm group-focus-within:shadow-xl group-focus-within:shadow-primary/5"
                    />
                </div>
            </div>

            <div className="space-y-2">
                <div className="flex justify-between items-center px-1">
                    <label className="text-xs font-semibold uppercase tracking-widest text-slate-500 dark:text-slate-400">Senha</label>
                    <button type="button" onClick={() => navigate('/recuperar')} className="text-[10px] font-bold text-primary hover:underline uppercase tracking-tighter">Esqueceu a senha?</button>
                </div>
                <div className="relative group">
                    <span className="material-icons-round absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors">lock</span>
                    <input
                        type="password"
                        required
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        placeholder="••••••••"
                        className="w-full bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-primary/20 focus:bg-white dark:focus:bg-white/10 rounded-2xl py-4 pl-14 pr-6 text-sm text-slate-900 dark:text-white outline-none transition-all shadow-sm group-focus-within:shadow-xl group-focus-within:shadow-primary/5"
                    />
                </div>
            </div>

            <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-5 rounded-2xl shadow-xl shadow-primary/20 hover:shadow-primary/30 active:scale-[0.98] transition-all flex items-center justify-center gap-3"
            >
                {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                    <>
                        <span>Acessar Painel</span>
                        <span className="material-icons-round">login</span>
                    </>
                )}
            </button>

            <div className="text-center pt-4">
                <p className="text-sm text-slate-500 dark:text-slate-400">
                    Não tem uma conta? {' '}
                    <button type="button" onClick={() => navigate('/cadastro')} className="text-primary font-bold hover:underline">Cadastre-se grátis</button>
                </p>
            </div>
        </div>
    );

    const renderSignupForm = () => (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-2">
                <label className="text-xs font-semibold uppercase tracking-widest text-slate-500 dark:text-slate-400 ml-1">Nome Completo</label>
                <div className="relative group">
                    <span className="material-icons-round absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors">person</span>
                    <input
                        type="text"
                        required
                        placeholder="John Doe"
                        className="w-full bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-primary/20 focus:bg-white dark:focus:bg-white/10 rounded-2xl py-4 pl-14 pr-6 text-sm text-slate-900 dark:text-white outline-none transition-all"
                    />
                </div>
            </div>

            <div className="space-y-2">
                <label className="text-xs font-semibold uppercase tracking-widest text-slate-500 dark:text-slate-400 ml-1">Email Profissional</label>
                <div className="relative group">
                    <span className="material-icons-round absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors">alternate_email</span>
                    <input
                        type="email"
                        required
                        placeholder="seu@email.com"
                        className="w-full bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-primary/20 focus:bg-white dark:focus:bg-white/10 rounded-2xl py-4 pl-14 pr-6 text-sm text-slate-900 dark:text-white outline-none transition-all"
                    />
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <label className="text-xs font-semibold uppercase tracking-widest text-slate-500 dark:text-slate-400 ml-1">Senha</label>
                    <input
                        type="password"
                        required
                        placeholder="••••••••"
                        className="w-full bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-primary/20 focus:bg-white dark:focus:bg-white/10 rounded-2xl py-4 px-6 text-sm text-slate-900 dark:text-white outline-none transition-all"
                    />
                </div>
                <div className="space-y-2">
                    <label className="text-xs font-semibold uppercase tracking-widest text-slate-500 dark:text-slate-400 ml-1">Confirmar</label>
                    <input
                        type="password"
                        required
                        placeholder="••••••••"
                        className="w-full bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-primary/20 focus:bg-white dark:focus:bg-white/10 rounded-2xl py-4 px-6 text-sm text-slate-900 dark:text-white outline-none transition-all"
                    />
                </div>
            </div>

            <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-5 rounded-2xl shadow-xl shadow-primary/20 hover:shadow-primary/30 active:scale-[0.98] transition-all flex items-center justify-center gap-3 mt-4"
            >
                {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                    <>
                        <span>Criar Conta Agora</span>
                        <span className="material-icons-round">how_to_reg</span>
                    </>
                )}
            </button>

            <div className="text-center pt-4">
                <p className="text-sm text-slate-500 dark:text-slate-400">
                    Já possui uma conta? {' '}
                    <button type="button" onClick={() => navigate('/login')} className="text-primary font-bold hover:underline">Fazer Login</button>
                </p>
            </div>
        </div>
    );

    const renderRecoverForm = () => (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="text-center space-y-2 mb-8">
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="material-icons-round text-3xl">lock_open</span>
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Recuperar Senha</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">Enviaremos um link de recuperação para o seu email cadastrado.</p>
            </div>

            <div className="space-y-2">
                <label className="text-xs font-semibold uppercase tracking-widest text-slate-500 dark:text-slate-400 ml-1">Email</label>
                <div className="relative group">
                    <span className="material-icons-round absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors">alternate_email</span>
                    <input
                        type="email"
                        required
                        placeholder="seu@email.com"
                        className="w-full bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-primary/20 focus:bg-white dark:focus:bg-white/10 rounded-2xl py-4 pl-14 pr-6 text-sm text-slate-900 dark:text-white outline-none transition-all"
                    />
                </div>
            </div>

            <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold py-5 rounded-2xl shadow-xl hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-3"
            >
                {isLoading ? (
                    <div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                ) : (
                    <>
                        <span>Enviar Instruções</span>
                        <span className="material-icons-round">send</span>
                    </>
                )}
            </button>

            <div className="text-center">
                <button type="button" onClick={() => navigate('/login')} className="text-sm text-slate-500 dark:text-slate-400 hover:text-primary transition-colors flex items-center justify-center gap-2 mx-auto">
                    <span className="material-icons-round text-lg">arrow_back</span>
                    Voltar para o login
                </button>
            </div>
        </div>
    );

    return (
        <div className="min-h-screen w-full flex overflow-hidden relative bg-white dark:bg-slate-950">
            {/* Abstract Background Elements */}
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-500/20 rounded-full blur-[120px] pointer-events-none" />

            {/* Hero Section (Left) - Hidden on Mobile */}
            <div className="hidden lg:flex flex-1 flex-col justify-center px-20 relative z-10">
                <div className="max-w-md space-y-6">
                    <div className="w-20 h-20 bg-primary rounded-3xl flex items-center justify-center shadow-2xl shadow-primary/40 rotate-12 hover:rotate-0 transition-all duration-700">
                        <span className="material-icons-round text-white text-5xl">hub</span>
                    </div>
                    <div className="space-y-2">
                        <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tighter leading-tight">
                            Gerencie sua comunicação com <span className="text-primary italic">precisão.</span>
                        </h1>
                        <p className="text-lg text-slate-500 dark:text-slate-400 leading-relaxed">
                            O dashboard definitivo para instâncias da Evolution API. Automação, análise e escala em um só lugar.
                        </p>
                    </div>

                    <div className="grid grid-cols-2 gap-6 pt-8">
                        <div className="bg-slate-50 dark:bg-white/5 p-4 rounded-2xl border border-slate-100 dark:border-white/5">
                            <span className="material-icons-round text-primary mb-2">speed</span>
                            <p className="text-sm font-bold text-slate-900 dark:text-white">Velocidade</p>
                            <p className="text-xs text-slate-500">Resposta em tempo real.</p>
                        </div>
                        <div className="bg-slate-50 dark:bg-white/5 p-4 rounded-2xl border border-slate-100 dark:border-white/5">
                            <span className="material-icons-round text-indigo-500 mb-2">security</span>
                            <p className="text-sm font-bold text-slate-900 dark:text-white">Segurança</p>
                            <p className="text-xs text-slate-500">Dados criptografados.</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Auth Card Section (Right) */}
            <div className="flex-1 flex flex-col items-center justify-center p-6 lg:p-12 relative z-20">
                {/* Theme Toggle (Absolute) */}
                <button
                    onClick={onToggleTheme}
                    className="absolute top-8 right-8 w-12 h-12 bg-slate-50 dark:bg-white/5 rounded-2xl flex items-center justify-center hover:bg-slate-100 dark:hover:bg-white/10 transition-all text-slate-500 dark:text-slate-400"
                >
                    <span className="material-icons-round">{isDarkMode ? 'light_mode' : 'dark_mode'}</span>
                </button>

                <div className="w-full max-w-md">
                    {/* Mobile Logo */}
                    <div className="lg:hidden flex justify-center mb-8">
                        <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center shadow-xl shadow-primary/30">
                            <span className="material-icons-round text-white text-4xl">hub</span>
                        </div>
                    </div>

                    <div className="bg-white/70 dark:bg-slate-900/40 backdrop-blur-3xl p-8 lg:p-12 rounded-[2.5rem] shadow-2xl border border-white dark:border-white/5 ring-1 ring-black/5 relative overflow-hidden">
                        {/* Glossy overlay */}
                        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-white/40 to-transparent" />

                        <form onSubmit={handleSubmit} className="relative z-10">
                            {initialView === 'login' && renderLoginForm()}
                            {initialView === 'signup' && renderSignupForm()}
                            {initialView === 'recover' && renderRecoverForm()}
                        </form>
                    </div>

                    <p className="text-center text-xs text-slate-400 dark:text-slate-500 mt-8 font-medium">
                        &copy; 2026 MyZap Dashboard. Todos os direitos reservados.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default AuthView;
